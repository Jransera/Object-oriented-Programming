//Yared Ansera (Jr)
//object oriented programming
//Assignment 2: Make a class named tweet entry and use a seperate class
//				named Driver to display the information.



//imports for the GetDate method
import java.text.SimpleDateFormat;
import java.util.Date;


public class TweetEntry {

	//formatting for getDate method
	SimpleDateFormat dtf=new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
	Date now=new Date();
	
//Instance variables:
	private String firstname;
	private String lastname;
	private int age;
	private String tweetText;
	private Date tweetDate;
//----------------------------------------------------------------//

	
//Constructors:	
	public TweetEntry(String fname, String lname, int age, String TweetText) {
		firstname=fname;
		lastname=lname;
		this.age=age;
		tweetText=TweetText;
		tweetDate=now;
	}
	
	public TweetEntry() {
		firstname=null;
		lastname=null;
		age=0;
		tweetText=null;
		tweetDate=now;
	}

	
	
//APIs:
	
	//Mutators:
		//set first name
	public void setfname(String fname) {
		firstname=fname;
	}
	
		//set last name
	public void setlname(String lname) {
		lastname=lname;
	}
	
		//set age
	public void setage(int age) {
		this.age=age;
	}

		//set tweetText
	public void setTweet(String text) {
		tweetText=text;
	}
	
		//set date
	public void setDate() {
		tweetDate=now;
	}
//----------------------------------------------------------------//
	
	
	//Accessors
	
		//get FirstName
	public String getfname() {
		return firstname;
	}
	
		//get LastName
	public String getlname() {
		return lastname;
	}
	
		//get age
	public int getAge() {
		return age;
	}
	
		//get text
	public String getText() {
		return tweetText;
	}
	
		//get Date
	public String getdate() {
		return dtf.format(tweetDate);
	}
//--------------------------------------------------------------//	
	
	
	//compare two TweetEntrys
	public boolean equals(TweetEntry tweetObj) {
		TweetEntry obj= (TweetEntry) tweetObj;
		
		if(this.firstname==obj.firstname
				&&this.lastname==obj.lastname
				&&this.age==obj.age
				&&this.tweetText.equals(obj.tweetText)
				&&this.tweetDate.equals(obj.tweetDate)) {
						return true;
			}
		
		
		else {
			return false;
			}
	}		
//-----------------------------------------------------------------//
	
	
	//turn all info into string except tweetText
	@Override
	public String toString() {
		return  "\n\tFirst Name:"+firstname+
				"\n\tLast Name: "+lastname+
				"\n\tAge: "+age+
				"\n\tUsername: #"+getUsername()+
				"\n\tDate Started "+getdate();
	}
//-----------------------------------------------------------------//	

	//Show only the first 140 characters of the tweet.
	public String showMyTweet() {
		return firstname+" "+lastname+"\n@"+getUsername()+"\n"+
	tweetText.substring(0, Math.min(tweetText.length(), 140))+"...";
	}
//-----------------------------------------------------------------//	
	
	//create a Username.
public String getUsername() {
	return ""+firstname.charAt(0)+lastname.charAt(0);
}	
//-----------------------------------------------------------------//	
	
	
}
	
	
	
	
	
