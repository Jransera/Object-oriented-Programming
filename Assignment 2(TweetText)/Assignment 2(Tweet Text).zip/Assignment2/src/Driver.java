//Yared Ansera (Jr)
//object oriented programming
//Assignment 2: Make a class named tweet entry and use a seperate class
//				named Driver to display the information.
public class Driver {

	public static void main(String[] args) {
		
		//construct a new Tweet.
		TweetEntry tweet1=new TweetEntry("John", "Smith",24,
				"The start date of the Summer Semester is just around the corner.\n"
				+ "I want to welcome all of you ahead of our first class meeting.\n"
				+"I am looking forward to working with all of you and I hope we will have a great semester.");
		
		
		//display the information using the getter methods.
		System.out.println("First Name: "+tweet1.getfname());
		System.out.println("Last Name: "+tweet1.getlname());
		System.out.println("Age: "+tweet1.getAge());
		System.out.println("Username: "+tweet1.getUsername());
		System.out.println("Tweet Date: "+tweet1.getdate());
		System.out.println("TweetText: "+tweet1.getText());
		
		System.out.println("\n\n");
		
		//Show My Tweet Output
		System.out.println(tweet1.showMyTweet());
		
		System.out.println("\n\n");
		
		//To String output
		System.out.println("Profile Summary"+tweet1.toString());
		
		
	}
}
